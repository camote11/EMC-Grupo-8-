# Informe: Simulador de Disney+

## Clases
| Clase | Atributos | Métodos |
|---|---|---|
| `Contenido` | titulo, genero, anio, calificaciones | calificar, promedio, mostrar_info |
| `Pelicula` (hereda de Contenido) | duracion | mostrar_info |
| `Serie` (hereda de Contenido) | temporadas | mostrar_info |
| `Usuario` | nombre, correo, clave, plan, mi_lista, historial | verificar_clave, agregar_a_mi_lista, reproducir, cambiar_plan |
| `Plataforma` | catalogo, usuarios | agregar_contenido, registrar_usuario, iniciar_sesion, buscar |

## Conceptos de POO usados
- **Constructores:** `__init__` en todas las clases.
- **Encapsulamiento:** atributos privados (`self.__titulo`) con métodos get.
- **Herencia:** `Pelicula` y `Serie` heredan de `Contenido`.
- **Polimorfismo:** `mostrar_info()` se muestra distinto en cada subclase.
- **Listas:** catálogo, usuarios, Mi lista, historial y calificaciones.
- **Menú interactivo:** en consola (`main.py`).

## Ejecución de prueba
Ver `capturas/ejecucion_prueba.txt`.
