class Contenido:
    """Clase base: todo lo que se puede ver (película o serie)."""

    def __init__(self, titulo, genero, anio):
        self.__titulo = titulo
        self.__genero = genero
        self.__anio = anio
        self.__calificaciones = []   # lista de puntajes

    def get_titulo(self):
        return self.__titulo

    def get_genero(self):
        return self.__genero

    def get_anio(self):
        return self.__anio

    def calificar(self, puntaje):
        """Guarda un puntaje entre 1 y 5."""
        if 1 <= puntaje <= 5:
            self.__calificaciones.append(puntaje)
            return True
        return False

    def promedio(self):
        if len(self.__calificaciones) == 0:
            return 0
        return sum(self.__calificaciones) / len(self.__calificaciones)

    def mostrar_info(self):
        return f"{self.__titulo} ({self.__anio}) - {self.__genero} - Nota: {self.promedio():.1f}"


class Pelicula(Contenido):
    """Película: agrega la duración."""

    def __init__(self, titulo, genero, anio, duracion):
        super().__init__(titulo, genero, anio)
        self.__duracion = duracion

    def mostrar_info(self):
        return "PELÍCULA: " + super().mostrar_info() + f" - {self.__duracion} min"


class Serie(Contenido):
    """Serie: agrega la cantidad de temporadas."""

    def __init__(self, titulo, genero, anio, temporadas):
        super().__init__(titulo, genero, anio)
        self.__temporadas = temporadas

    def mostrar_info(self):
        return "SERIE: " + super().mostrar_info() + f" - {self.__temporadas} temporadas"
