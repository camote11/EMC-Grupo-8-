class Plataforma:
    """Guarda el catálogo y los usuarios registrados."""

    def __init__(self):
        self.__catalogo = []
        self.__usuarios = []

    def agregar_contenido(self, contenido):
        self.__catalogo.append(contenido)

    def get_catalogo(self):
        return self.__catalogo

    def registrar_usuario(self, usuario):
        for u in self.__usuarios:
            if u.get_correo() == usuario.get_correo():
                return False          # correo repetido
        self.__usuarios.append(usuario)
        return True

    def iniciar_sesion(self, correo, clave):
        for u in self.__usuarios:
            if u.get_correo() == correo and u.verificar_clave(clave):
                return u
        return None

    def buscar(self, texto):
        resultado = []
        for c in self.__catalogo:
            if texto.lower() in c.get_titulo().lower():
                resultado.append(c)
        return resultado
