from contenido import Pelicula, Serie
from usuario import Usuario
from plataforma import Plataforma


def cargar_datos(plataforma):
    plataforma.agregar_contenido(Pelicula("El Rey León", "Animación", 1994, 88))
    plataforma.agregar_contenido(Pelicula("Frozen", "Animación", 2013, 102))
    plataforma.agregar_contenido(Pelicula("Coco", "Animación", 2017, 105))
    plataforma.agregar_contenido(Pelicula("Avengers: Endgame", "Acción", 2019, 181))
    plataforma.agregar_contenido(Pelicula("Black Panther", "Acción", 2018, 134))
    plataforma.agregar_contenido(Serie("The Mandalorian", "Ciencia ficción", 2019, 3))
    plataforma.agregar_contenido(Serie("Loki", "Fantasía", 2021, 2))
    plataforma.agregar_contenido(Serie("Bluey", "Animación", 2018, 3))
    # usuario de prueba
    plataforma.registrar_usuario(Usuario("Demo", "demo@disney.com", "1234", "Premium"))


def mostrar_catalogo(lista):
    if len(lista) == 0:
        print("No hay resultados.")
    for i, c in enumerate(lista, 1):
        print(f"{i}. {c.mostrar_info()}")


def elegir(lista):
    """Pide un número y devuelve el contenido elegido (o None)."""
    try:
        n = int(input("Número del contenido: "))
        return lista[n - 1]
    except (ValueError, IndexError):
        print("Opción inválida.")
        return None


def menu_usuario(plataforma, usuario):
    catalogo = plataforma.get_catalogo()
    while True:
        print(f"\n--- Hola {usuario.get_nombre()} (Plan {usuario.get_plan()}) ---")
        print("1. Ver catálogo")
        print("2. Buscar por título")
        print("3. Reproducir")
        print("4. Agregar a Mi lista")
        print("5. Ver Mi lista")
        print("6. Calificar")
        print("7. Ver historial")
        print("8. Cambiar de plan")
        print("9. Cerrar sesión")
        op = input("Opción: ")

        if op == "1":
            mostrar_catalogo(catalogo)
        elif op == "2":
            mostrar_catalogo(plataforma.buscar(input("Título: ")))
        elif op == "3":
            mostrar_catalogo(catalogo)
            c = elegir(catalogo)
            if c:
                usuario.reproducir(c)
                print("▶ Reproduciendo:", c.get_titulo())
                if usuario.get_plan() == "Basico":
                    print("(Anuncio de 15 segundos...)")
        elif op == "4":
            mostrar_catalogo(catalogo)
            c = elegir(catalogo)
            if c:
                if usuario.agregar_a_mi_lista(c):
                    print("Agregado a Mi lista.")
                else:
                    print("Ya estaba en tu lista.")
        elif op == "5":
            mostrar_catalogo(usuario.get_mi_lista())
        elif op == "6":
            mostrar_catalogo(catalogo)
            c = elegir(catalogo)
            if c:
                try:
                    puntaje = int(input("Puntaje (1-5): "))
                    if c.calificar(puntaje):
                        print("Gracias por calificar.")
                    else:
                        print("El puntaje debe ser de 1 a 5.")
                except ValueError:
                    print("Ingresa un número.")
        elif op == "7":
            mostrar_catalogo(usuario.get_historial())
        elif op == "8":
            nuevo = input("Nuevo plan (Basico/Premium): ").capitalize()
            if nuevo in ("Basico", "Premium"):
                usuario.cambiar_plan(nuevo)
                print("Plan cambiado a", nuevo)
            else:
                print("Plan inválido.")
        elif op == "9":
            break
        else:
            print("Opción inválida.")


def main():
    plataforma = Plataforma()
    cargar_datos(plataforma)
    while True:
        print("\n=== DISNEY+ ===")
        print("1. Registrarse")
        print("2. Iniciar sesión")
        print("3. Salir")
        op = input("Opción: ")
        if op == "1":
            nombre = input("Nombre: ")
            correo = input("Correo: ")
            clave = input("Clave: ")
            plan = input("Plan (Basico/Premium): ").capitalize()
            if plan not in ("Basico", "Premium"):
                plan = "Basico"
            if plataforma.registrar_usuario(Usuario(nombre, correo, clave, plan)):
                print("Cuenta creada.")
            else:
                print("Ese correo ya existe.")
        elif op == "2":
            usuario = plataforma.iniciar_sesion(input("Correo: "), input("Clave: "))
            if usuario:
                menu_usuario(plataforma, usuario)
            else:
                print("Correo o clave incorrectos.")
        elif op == "3":
            print("Hasta pronto.")
            break
        else:
            print("Opción inválida.")


main()
