class Usuario:
    """Usuario de la plataforma con su plan, Mi lista e historial."""

    def __init__(self, nombre, correo, clave, plan):
        self.__nombre = nombre
        self.__correo = correo
        self.__clave = clave
        self.__plan = plan            # "Basico" o "Premium"
        self.__mi_lista = []
        self.__historial = []

    def get_nombre(self):
        return self.__nombre

    def get_correo(self):
        return self.__correo

    def get_plan(self):
        return self.__plan

    def cambiar_plan(self, plan):
        self.__plan = plan

    def verificar_clave(self, clave):
        return self.__clave == clave

    def agregar_a_mi_lista(self, contenido):
        if contenido in self.__mi_lista:
            return False
        self.__mi_lista.append(contenido)
        return True

    def get_mi_lista(self):
        return self.__mi_lista

    def reproducir(self, contenido):
        self.__historial.append(contenido)

    def get_historial(self):
        return self.__historial
