# Simulador de Disney+ (POO en Python)

Evaluación Grupal 1 - Lenguaje de Programación II - 2026-2

## Integrantes
| Usuario GitHub | Nombres y apellidos |
|---|---|
| @usuario1 | Nombre Apellido |
| @usuario2 | Nombre Apellido |
| @usuario3 | Nombre Apellido |

## Escenario
Una plataforma de streaming donde el usuario se registra, elige un plan, ve el catálogo,
reproduce películas y series, las califica y las guarda en "Mi lista".

## Ejecutar
```
cd src
python main.py
```
Usuario de prueba: `demo@disney.com` / `1234`

## Diagrama de clases
```mermaid
classDiagram
    class Plataforma {
        -catalogo
        -usuarios
        +agregar_contenido()
        +registrar_usuario()
        +iniciar_sesion()
        +buscar()
    }
    class Usuario {
        -nombre
        -correo
        -clave
        -plan
        -mi_lista
        -historial
        +verificar_clave()
        +agregar_a_mi_lista()
        +reproducir()
        +cambiar_plan()
    }
    class Contenido {
        -titulo
        -genero
        -anio
        -calificaciones
        +calificar()
        +promedio()
        +mostrar_info()
    }
    class Pelicula {
        -duracion
        +mostrar_info()
    }
    class Serie {
        -temporadas
        +mostrar_info()
    }
    Plataforma o-- Usuario
    Plataforma o-- Contenido
    Contenido <|-- Pelicula
    Contenido <|-- Serie
    Usuario --> Contenido
```
